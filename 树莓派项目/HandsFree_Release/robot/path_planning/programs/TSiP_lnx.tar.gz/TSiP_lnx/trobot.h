﻿#include "t2dpose.h"
#ifndef TROBOT_H
#define TROBOT_H

class TRobot : public T2DPose
{
    int m_size;//机器人正方形边长
    int m_speed;//每一个步进的长度
    enum STATE{
        OK,
        ERROR
    }m_state;
public:
    TRobot();
    TRobot(const double x,const double y,const double phi);
    void initialState(const double x,const double y,const double phi);
    void setSpeed(const int x);
    int getSpeed();
};

#endif // TROBOT_H
