﻿#include "t2dpoint.h"
#ifndef T2DPOSE_H
#define T2DPOSE_H

class T2DPose : public T2DPoint
{
    double m_phi;
public:
    T2DPose();
    T2DPose(const double x,const double y,const double phi);
    void setXYPhi(const double x,const double y,const double phi);
    void setPhi(const double phi);
    double getPhi();

};

#endif // T2DPOSE_H
