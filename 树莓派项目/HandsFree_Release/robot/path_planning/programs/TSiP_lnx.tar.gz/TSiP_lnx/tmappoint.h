﻿#ifndef TMAPPOINT_H
#define TMAPPOINT_H
#include "t2dpoint.h"
class TMapPoint : public T2DPoint
{
public:
    enum LANDFORMS{
        FLAT,
        OBSTACLE,
        UNKNOWN
    };
private:
    LANDFORMS m_landforms;
public:

    TMapPoint();
    TMapPoint(const double x,const double y,enum LANDFORMS lf);
    void setobstacle();
    void setflat();
    bool isObstacle();
    bool isFlat();
};

#endif // TMAPPOINT_H
