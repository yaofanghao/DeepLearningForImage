#include "t2dpose.h"

T2DPose::T2DPose()
{
}
T2DPose::T2DPose(const double x, const double y, const double phi):T2DPoint(x,y)
{
    m_phi=phi;
}
void T2DPose::setXYPhi(const double x, const double y, const double phi)
{
    setXY(x,y);
    m_phi=phi;
}
double T2DPose::getPhi()
{
    return m_phi;
}
void T2DPose::setPhi(const double phi){
    m_phi = phi;
}
