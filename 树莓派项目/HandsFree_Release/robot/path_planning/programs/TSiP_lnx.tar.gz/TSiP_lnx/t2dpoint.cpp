#include "t2dpoint.h"

T2DPoint::T2DPoint()
{
}
T2DPoint::T2DPoint(const double x, const double y){
  m_x=x;
  m_y=y;
}
bool T2DPoint::setXY(const double x, const double y){
   m_x=x;
   m_y=y;
   return true;
}
double T2DPoint::getX(){
    return m_x;
}
double T2DPoint::getY(){
    return m_y;
}
bool T2DPoint::operator ==(T2DPoint point){
    if(this->m_x==point.getX() && this->m_y==point.getY()) return true;
    else return false;
}
