#include "tmappoint.h"

TMapPoint::TMapPoint()
{
    m_landforms=FLAT;
}
TMapPoint::TMapPoint(const double x, const double y, LANDFORMS lf):T2DPoint(x,y){
    m_landforms=lf;
}
void TMapPoint::setflat(){
    m_landforms=FLAT;
}
void TMapPoint::setobstacle(){
    m_landforms=OBSTACLE;
}
bool TMapPoint::isObstacle(){
    if (m_landforms==OBSTACLE)
        return true;
    else
        return false;
}
bool TMapPoint::isFlat(){
    if (m_landforms==FLAT)
        return true;
    else
        return false;
}

