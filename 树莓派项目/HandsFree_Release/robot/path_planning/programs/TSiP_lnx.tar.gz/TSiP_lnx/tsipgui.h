﻿#include <QtGlobal>
#include <QObject>
#include <qwt_series_data.h>
#include <qwt_point_data.h>
#include <qwt_plot_curve.h>
#include <qwt_plot.h>
#include <qwt_legend.h>
#include <qwt_plot_grid.h>
#include <qwt_magnifier.h>
#include <qwt_plot_magnifier.h>
#include <qwt_plot_panner.h>
#include <qwt_plot_picker.h>
#include <qwt_picker_machine.h>
#include <qwt_plot_curve.h>
#include "tmap.h"
#include <QVector>
#include <QPointF>
#include <qwt_symbol.h>
#include <qcolor.h>
#include <qpainter.h>
#include <qwt_scale_engine.h>
#include "tmappoint.h"
#include "trobot.h"
#include "qwt_symbol.h"

#ifndef TSIPGUI_H
#define TSIPGUI_H



class TSiPGUI
{
    QwtPlot *plot;
    QwtPlotCurve *curve_map;
    QwtPlotCurve *curve_boundary;
    QwtPlotCurve *curve_scan;
    QwtPlotCurve *curve_nav;
    QwtPlotCurve *curve_nav2;
    QwtPlotCurve *curve_rob;
    QwtPlotCurve *d_curve;//for UnitTest demo
public:
    TSiPGUI();
    TSiPGUI(QwtPlot *uiplot);
    void UnitTest(void);
    void drawCurve(QwtPlotCurve *curve, QPolygonF *sample);
    void drawCurve(QwtPlotCurve *curve,const QPolygonF &sample);
    void drawMap(TMap *map);
    void drawScan(const QVector<TMapPoint> *scanPoint);
    void drawRob(TRobot *rob );
    void draw_nav(const QVector<T2DPoint> *navPoint);
//    void qtUIClient(QwtPlot *plot);
    QwtPlotCurve* getCurve_nav2(){
        return curve_nav2;
    }

private:
    void initPlot(void);
    void setRobStyele(TRobot *rob);
};

#endif // TSIPGUI_H
