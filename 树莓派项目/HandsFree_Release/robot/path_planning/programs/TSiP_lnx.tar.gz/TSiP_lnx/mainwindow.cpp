﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLabel>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //初始化变量
    map = new TMap();
    rob = new TRobot();
    scan = new TScan();
    gui = new TSiPGUI(ui->qwtPlot);
    astarSys = new astar();
    VFFSys = new VFFAlgorithm();
    timer = new QTimer(this);

    //    connect(timer, SIGNAL(timeout()), this, SLOT(timeUpdate()));

    target.setXY(ui->lineEdit->text().toDouble(),
                 ui->lineEdit_2->text().toDouble());


    map->loadFromPicture("test.png");
    gui->drawMap(map);
    rob->setXYPhi(ui->lineEdit_3->text().toDouble(),
                  ui->lineEdit_4->text().toDouble(),135);
    scan->setMap(map);
    scan->setRobot(rob);
    scan->setSensor(360,360,ui->lineEdit_8->text().toInt());
    gui->drawScan(&(scan->scanRefresh()));
    gui->drawRob(rob);

    //    VFFSys = new VFFAlgorithm();
    //    VFFSys->VFFUnitTest();

}

void MainWindow::UnitTest(){

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *)//重写绘图虚函数
{
}

void MainWindow::on_action_triggered()//打开文件
{
}

void MainWindow::on_pushButton_2_clicked()// 设置导航位置
{
    QString stringX,stringY;
    stringX = ui->lineEdit->text();
    stringY = ui->lineEdit_2->text();
    target.setXY(stringX.toDouble(),stringY.toDouble());
    QString tmp;
    tmp+=tr("target Pos:(");
    tmp+=stringX;
    tmp+=",";
    tmp+=stringY;
    tmp+=")";
    ui->label_2->setText(tmp);
}

void MainWindow::on_pushButton_3_clicked()
{
    QString stringX,stringY;
    stringX = ui->lineEdit_3->text();
    stringY = ui->lineEdit_4->text();
    rob->setXY(stringX.toDouble(),stringY.toDouble());
    QString tmp;
    tmp+=tr("robot Pos:(");
    tmp+=stringX;
    tmp+=",";
    tmp+=stringY;
    tmp+=")";
    ui->label_3->setText(tmp);
    gui->drawScan(&(scan->scanRefresh()));
    gui->drawRob(rob);
    ui->qwtPlot->replot();
}

void MainWindow::on_checkBox_clicked()
{
    ui->checkBox->setChecked(true);
    ui->checkBox_2->setChecked(false);
    ui->checkBox_3->setChecked(false);
    ui->checkBox_4->setChecked(false);

}

void MainWindow::on_checkBox_2_clicked()
{
    ui->checkBox->setChecked(false);
    ui->checkBox_2->setChecked(true);
    ui->checkBox_3->setChecked(false);
    ui->checkBox_4->setChecked(false);
}

void MainWindow::on_checkBox_3_clicked()
{
    ui->checkBox->setChecked(false);
    ui->checkBox_2->setChecked(false);
    ui->checkBox_3->setChecked(true);
    ui->checkBox_4->setChecked(false);

}

void MainWindow::timeUpdate(){
    qDebug()<<"hi I'm here";
}

void MainWindow::on_pushButton_clicked(bool checked)
{
    if(checked){//开始仿真
        ui->pushButton->setText("stop simulation");
        if(ui->checkBox->checkState()) aStarAlgorithm();
        if(ui->checkBox_2->checkState()) randomastarVFFAlgorithm();
        if(ui->checkBox_3->checkState()) aStarVFFAlgorithm();
        if(ui->checkBox_4->checkState()) simpleaAstarVFFAlgorithm();
    }else{//停止仿真
        ui->pushButton->setText("start simulation");\
        timer->stop();
        if(ui->checkBox->checkState())
            disconnect(timer, SIGNAL(timeout()), this, SLOT(aStarPeriod()));
        if(ui->checkBox_3->checkState())
            disconnect(timer, SIGNAL(timeout()), this, SLOT(aStarVFFPeriod()));
    }
}
void MainWindow::aStarAlgorithm(){
    ui->textEdit->append(tr("start A* algorithm"));
    int num= astarSys->aStar_Init(map,target);
    //    QString().setNum(num)
    QString tmp = tr("A* algorithm loop num :");
    tmp+=QString().setNum(num);
    ui->textEdit->append(tmp);

    QVector<T2DPoint> *navpoint = new QVector<T2DPoint>;
    T2DPoint pstate(rob->getX(),rob->getY());
    for(;1;){

        pstate = astarSys->aStar_nav_step(&pstate);
        navpoint->append(pstate);
        if (pstate==target) break;
    }
    qDebug()<<navpoint->size();
    gui->draw_nav(navpoint);
    this->update();

    connect(timer, SIGNAL(timeout()), this, SLOT(aStarPeriod()));
    timer->start(ui->lineEdit_5->text().toInt());
}
void MainWindow::simpleaAstarVFFAlgorithm(){
    ui->textEdit->append(tr("random A* VFF algorithm"));
    int num= astarSys->aStar_Init(map,target);
    //    QString().setNum(num)
    QString tmp = tr("A* algorithm loop num :");
    tmp+=QString().setNum(num);
    ui->textEdit->append(tmp);  //init A*

    //init  vff
    VFFSys->setTScan(scan);

    QVector<T2DPoint> *navpoint = new QVector<T2DPoint>;
    T2DPoint pstate(rob->getX(),rob->getY());
    for(;1;){

        pstate = astarSys->aStar_nav_step(&pstate);
        navpoint->append(pstate);
        if (pstate==target) break;
    }
    //    qDebug()<<navpoint->size();
    gui->draw_nav(navpoint);
    this->update();

    connect(timer, SIGNAL(timeout()), this, SLOT(simpleaAstarVFFPeriod()));
    timer->start(ui->lineEdit_5->text().toInt());
}
void MainWindow::simpleaAstarVFFPeriod(){
    QVector2D VFFResult;
    T2DPoint aresult;

    T2DPoint pstate(rob->getX(),rob->getY());
    //获取两种算法的结果
    aresult = astarSys->aStar_nav_step(&pstate);
    VFFResult = VFFSys->VFFstep();
    double believe = VFFResult.length();
    //根据VFF方法的置信判断是否采用
    double atantmp ;
    int degreetmp;
    atantmp = qAtan2(VFFResult.y(),VFFResult.x());
    degreetmp = (int)degree(atantmp);
    rob->setPhi(degreetmp);
    int randvalue;
    randvalue =  qrand()%100;
    static QPolygonF *realnav = new QPolygonF();
    realnav->append(QPointF(pstate.getX(),pstate.getY()));
    gui->drawCurve(gui->getCurve_nav2(),realnav);
    if(believe>10){//采用vff结果
        rob->setPhi(degreetmp);
        ui->textEdit->append(tr("use VFF"));
        if(degreetmp>-22.5&&degreetmp<=22.5)
            rob->setXYPhi(pstate.getX()+1,pstate.getY(),0);
        if(degreetmp>22.5&&degreetmp<=67.5)
            rob->setXYPhi(pstate.getX()+1,pstate.getY()+1,45);
        if(degreetmp>67.5&&degreetmp<=112.5)
            rob->setXYPhi(pstate.getX(),pstate.getY()+1,90);
        if(degreetmp>112.5&&degreetmp<=157.5)
            rob->setXYPhi(pstate.getX()-1,pstate.getY()+1,135);
        if(degreetmp>-67.5&&degreetmp<=-22.5)
            rob->setXYPhi(pstate.getX()+1,pstate.getY()-1,-45);
        if(degreetmp>-112.5&&degreetmp<=-67.5)
            rob->setXYPhi(pstate.getX(),pstate.getY()-1,-90);
        if(degreetmp>-157.5&&degreetmp<=-112.5)
            rob->setXYPhi(pstate.getX()-1,pstate.getY()-1,-135);
        if(degreetmp<=-157.5||degreetmp>=157.5)
            rob->setXYPhi(pstate.getX()-1,pstate.getY(),180);
    }else{//采用A*结果
        ui->textEdit->append(tr("use a*"));
        rob->setXY(aresult.getX(),aresult.getY());
        int dx=aresult.getX()-pstate.getX();
        int dy=aresult.getY()-pstate.getY();
        if(dx==1&&dy==0)rob->setPhi(0);
        if(dx==1&&dy==1)rob->setPhi(45);
        if(dx==0&&dy==1)rob->setPhi(90);
        if(dx==-1&&dy==1)rob->setPhi(135);
        if(dx==-1&&dy==0)rob->setPhi(180);
        if(dx==-1&&dy==-1)rob->setPhi(-135);
        if(dx==0&&dy==-1)rob->setPhi(-90);
        if(dx==1&&dy==-1)rob->setPhi(-45);
    }

    ui->textEdit->append(tr("believe value :")+=QString().setNum(believe));

    gui->drawScan(&(scan->scanRefresh()));
    gui->drawRob(rob);
    if(pstate==target){
        realnav->clear();

        timer->stop();
        disconnect(timer, SIGNAL(timeout()), this, SLOT(aStarPeriod()));
    }
    ui->qwtPlot->replot();
    this->update();
}

void MainWindow::randomastarVFFAlgorithm(){
    ui->textEdit->append(tr("random A* VFF algorithm"));
    int num= astarSys->aStar_Init(map,target);
    //    QString().setNum(num)
    QString tmp = tr("A* algorithm loop num :");
    tmp+=QString().setNum(num);
    ui->textEdit->append(tmp);  //init A*

    //init  vff
    VFFSys->setTScan(scan);

    QVector<T2DPoint> *navpoint = new QVector<T2DPoint>;
    T2DPoint pstate(rob->getX(),rob->getY());
    for(;1;){

        pstate = astarSys->aStar_nav_step(&pstate);
        navpoint->append(pstate);
        if (pstate==target) break;
    }
    //    qDebug()<<navpoint->size();
    gui->draw_nav(navpoint);
    this->update();

    connect(timer, SIGNAL(timeout()), this, SLOT(randomastarVFFPeriod()));
    timer->start(ui->lineEdit_5->text().toInt());
}
void MainWindow::randomastarVFFPeriod(){
    QVector2D VFFResult;
    T2DPoint aresult;

    T2DPoint pstate(rob->getX(),rob->getY());
    //获取两种算法的结果
    aresult = astarSys->aStar_nav_step(&pstate);
    VFFResult = VFFSys->VFFstep();
    double believe = VFFResult.length();
    //根据VFF方法的置信判断是否采用
    double atantmp ;
    int degreetmp;
    atantmp = qAtan2(VFFResult.y(),VFFResult.x());
    degreetmp = (int)degree(atantmp);
    rob->setPhi(degreetmp);
    int randvalue;
    randvalue =  qrand()%100;
    static QPolygonF *realnav = new QPolygonF();
    realnav->append(QPointF(pstate.getX(),pstate.getY()));
    gui->drawCurve(gui->getCurve_nav2(),realnav);
    if(randvalue>40&&believe>2){//采用vff结果
        rob->setPhi(degreetmp);
        ui->textEdit->append(tr("use VFF"));
        if(degreetmp>-22.5&&degreetmp<=22.5)
            rob->setXYPhi(pstate.getX()+1,pstate.getY(),0);
        if(degreetmp>22.5&&degreetmp<=67.5)
            rob->setXYPhi(pstate.getX()+1,pstate.getY()+1,45);
        if(degreetmp>67.5&&degreetmp<=112.5)
            rob->setXYPhi(pstate.getX(),pstate.getY()+1,90);
        if(degreetmp>112.5&&degreetmp<=157.5)
            rob->setXYPhi(pstate.getX()-1,pstate.getY()+1,135);
        if(degreetmp>-67.5&&degreetmp<=-22.5)
            rob->setXYPhi(pstate.getX()+1,pstate.getY()-1,-45);
        if(degreetmp>-112.5&&degreetmp<=-67.5)
            rob->setXYPhi(pstate.getX(),pstate.getY()-1,-90);
        if(degreetmp>-157.5&&degreetmp<=-112.5)
            rob->setXYPhi(pstate.getX()-1,pstate.getY()-1,-135);
        if(degreetmp<=-157.5||degreetmp>=157.5)
            rob->setXYPhi(pstate.getX()-1,pstate.getY(),180);
    }else{//采用A*结果
        ui->textEdit->append(tr("use a*"));
        rob->setXY(aresult.getX(),aresult.getY());
        int dx=aresult.getX()-pstate.getX();
        int dy=aresult.getY()-pstate.getY();
        if(dx==1&&dy==0)rob->setPhi(0);
        if(dx==1&&dy==1)rob->setPhi(45);
        if(dx==0&&dy==1)rob->setPhi(90);
        if(dx==-1&&dy==1)rob->setPhi(135);
        if(dx==-1&&dy==0)rob->setPhi(180);
        if(dx==-1&&dy==-1)rob->setPhi(-135);
        if(dx==0&&dy==-1)rob->setPhi(-90);
        if(dx==1&&dy==-1)rob->setPhi(-45);
    }

    ui->textEdit->append(tr("believe value :")+=QString().setNum(believe));

    gui->drawScan(&(scan->scanRefresh()));
    gui->drawRob(rob);
    if(pstate==target){
        realnav->clear();

        timer->stop();
        disconnect(timer, SIGNAL(timeout()), this, SLOT(aStarPeriod()));
    }
    ui->qwtPlot->replot();
    this->update();
}

void MainWindow::aStarPeriod(){
    //    qDebug()<<"in the a star loop";
    T2DPoint pstate(rob->getX(),rob->getY());
    T2DPoint aresult;
    aresult = astarSys->aStar_nav_step(&pstate);
    rob->setXY(aresult.getX(),aresult.getY());
    int dx=aresult.getX()-pstate.getX();
    int dy=aresult.getY()-pstate.getY();
    if(dx==1&&dy==0)rob->setPhi(0);
    if(dx==1&&dy==1)rob->setPhi(45);
    if(dx==0&&dy==1)rob->setPhi(90);
    if(dx==-1&&dy==1)rob->setPhi(135);
    if(dx==-1&&dy==0)rob->setPhi(180);
    if(dx==-1&&dy==-1)rob->setPhi(-135);
    if(dx==0&&dy==-1)rob->setPhi(-90);
    if(dx==1&&dy==-1)rob->setPhi(-45);

    gui->drawScan(&(scan->scanRefresh()));
    gui->drawRob(rob);
    if(pstate==target){
        timer->stop();
        disconnect(timer, SIGNAL(timeout()), this, SLOT(aStarPeriod()));
    }
    //    ui->qwtPlot->update(ui->qwtPlot->geometry());
    ui->qwtPlot->replot();
    //    ui->qwtPlot->repaint();
    this->update();
}
void MainWindow::aStarVFFAlgorithm(){
    ui->textEdit->append(tr("start A* VFF algorithm"));
    int num= astarSys->aStar_Init(map,target);
    //    QString().setNum(num)
    QString tmp = tr("A* algorithm loop num :");
    tmp+=QString().setNum(num);
    ui->textEdit->append(tmp);  //init A*

    //init  vff
    VFFSys->setTScan(scan);

    QVector<T2DPoint> *navpoint = new QVector<T2DPoint>;
    T2DPoint pstate(rob->getX(),rob->getY());
    for(;1;){

        pstate = astarSys->aStar_nav_step(&pstate);
        navpoint->append(pstate);
        if (pstate==target) break;
    }
    //    qDebug()<<navpoint->size();
    gui->draw_nav(navpoint);
    this->update();

    connect(timer, SIGNAL(timeout()), this, SLOT(aStarVFFPeriod()));
    timer->start(ui->lineEdit_5->text().toInt());
}

void MainWindow::aStarVFFPeriod(){
    QVector2D VFFResult;
    T2DPoint aresult;

    T2DPoint pstate(rob->getX(),rob->getY());
    //获取两种算法的结果
    aresult = astarSys->aStar_nav_step(&pstate);
    VFFResult = VFFSys->VFFstep();
    double believe = VFFResult.length();
    //根据VFF方法的置信判断是否采用
    double atantmp ;
    int degreetmp;
    atantmp = qAtan2(VFFResult.y(),VFFResult.x());
    degreetmp = (int)degree(atantmp);
    rob->setPhi(degreetmp);
    int randvalue;
    randvalue =  qrand()%100;
    static QPolygonF *realnav = new QPolygonF();
    realnav->append(QPointF(pstate.getX(),pstate.getY()));
    gui->drawCurve(gui->getCurve_nav2(),realnav);
    if((randvalue>2&&believe>100)||
            (randvalue>10&&believe>70)||
            (randvalue>50&&believe>30)||
            (randvalue>60&&believe>15)||
            (randvalue>90&&believe>5)){//采用vff结果
        rob->setPhi(degreetmp);
        ui->textEdit->append(tr("use VFF"));
        if(degreetmp>-22.5&&degreetmp<=22.5)
            rob->setXYPhi(pstate.getX()+1,pstate.getY(),0);
        if(degreetmp>22.5&&degreetmp<=67.5)
            rob->setXYPhi(pstate.getX()+1,pstate.getY()+1,45);
        if(degreetmp>67.5&&degreetmp<=112.5)
            rob->setXYPhi(pstate.getX(),pstate.getY()+1,90);
        if(degreetmp>112.5&&degreetmp<=157.5)
            rob->setXYPhi(pstate.getX()-1,pstate.getY()+1,135);
        if(degreetmp>-67.5&&degreetmp<=-22.5)
            rob->setXYPhi(pstate.getX()+1,pstate.getY()-1,-45);
        if(degreetmp>-112.5&&degreetmp<=-67.5)
            rob->setXYPhi(pstate.getX(),pstate.getY()-1,-90);
        if(degreetmp>-157.5&&degreetmp<=-112.5)
            rob->setXYPhi(pstate.getX()-1,pstate.getY()-1,-135);
        if(degreetmp<=-157.5||degreetmp>=157.5)
            rob->setXYPhi(pstate.getX()-1,pstate.getY(),180);
    }else{//采用A*结果
        ui->textEdit->append(tr("use a*"));
        rob->setXY(aresult.getX(),aresult.getY());
        int dx=aresult.getX()-pstate.getX();
        int dy=aresult.getY()-pstate.getY();
        if(dx==1&&dy==0)rob->setPhi(0);
        if(dx==1&&dy==1)rob->setPhi(45);
        if(dx==0&&dy==1)rob->setPhi(90);
        if(dx==-1&&dy==1)rob->setPhi(135);
        if(dx==-1&&dy==0)rob->setPhi(180);
        if(dx==-1&&dy==-1)rob->setPhi(-135);
        if(dx==0&&dy==-1)rob->setPhi(-90);
        if(dx==1&&dy==-1)rob->setPhi(-45);
    }

    ui->textEdit->append(tr("believe value :")+=QString().setNum(believe));

    gui->drawScan(&(scan->scanRefresh()));
    gui->drawRob(rob);
    if(pstate==target){
        realnav->clear();

        timer->stop();
        disconnect(timer, SIGNAL(timeout()), this, SLOT(aStarPeriod()));
    }
    ui->qwtPlot->replot();
    this->update();
}

void MainWindow::on_pushButton_4_clicked()
{
    scan->setSensor(360,180,ui->lineEdit_8->text().toInt());
    ui->textEdit->append(tr("set the Sensor range"));
    gui->drawScan(&(scan->scanRefresh()));
    ui->qwtPlot->replot();
}

double MainWindow::degree(const double radians)
{
    return radians*180/PI;
}

double MainWindow::radians(const double degree)
{
    return degree*PI/180;
}

void MainWindow::on_checkBox_4_clicked()
{
    ui->checkBox->setChecked(false);
    ui->checkBox_2->setChecked(false);
    ui->checkBox_3->setChecked(false);
    ui->checkBox_4->setChecked(true);

}
