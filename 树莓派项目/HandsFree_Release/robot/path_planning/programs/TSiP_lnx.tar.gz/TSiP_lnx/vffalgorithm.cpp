#include "vffalgorithm.h"

VFFAlgorithm::VFFAlgorithm()
{
    Fconst = 1000;
}
void VFFAlgorithm::setTScan(TScan *scanToLoad){
    scan = scanToLoad;
}

QVector2D VFFAlgorithm::VFFstep(){
    QVector<TMapPoint> scanPoint;
    scanPoint = scan->scanRefresh();
    int pointNum = scanPoint.size();
    if(pointNum==0) return QVector2D(0,0);//如果没有扫描到点给一个空数量;
    double sx=scan->getRobot()->getX();
    double sy=scan->getRobot()->getY();
    double x,y;
    double fValue;
    QVector2D tmpVector;
    for (int i=0;i<pointNum;i++){
        x=scanPoint[i].getX();
        y=scanPoint[i].getY();
        tmpVector = QVector2D(x-sx,y-sy);
        fValue = Fconst / tmpVector.lengthSquared();
        tmpVector.normalize();
        tmpVector*=fValue;
        VFFresult-=tmpVector;
    }
    VFFresult /= pointNum;
    return VFFresult;
}
void VFFAlgorithm::VFFUnitTest(){
    TMap *map = new TMap();
    map->loadFromPicture("test.png");
    TRobot *rob = new TRobot(3,3,0);
    TScan *robscan = new TScan();
    robscan->setMap(map);
    robscan->setRobot(rob);
    robscan->setSensor(360,180,50);
    scan = robscan;
    //    T2DPoint aaa = VFFstep();
}
