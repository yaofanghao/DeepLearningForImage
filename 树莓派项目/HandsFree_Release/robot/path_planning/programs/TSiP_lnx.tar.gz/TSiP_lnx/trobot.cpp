#include "trobot.h"

TRobot::TRobot()
{
}
TRobot::TRobot(const double x, const double y, const double phi){
    T2DPose::setXYPhi(x,y,phi);
}

void TRobot::initialState(const double x,const double y,const double phi)
{
    T2DPose::setXYPhi(x,y,phi);
}
void TRobot::setSpeed(const int speed)
{
    m_speed=speed;
}
int TRobot::getSpeed()
{
    return m_speed;
}
