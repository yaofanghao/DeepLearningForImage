﻿#ifndef ASTAR_H
#define ASTAR_H

#include "t2dpoint.h"
#include "tmap.h"
#include <QVector>

class astar
{
public:
    QVector<float> VmapCV;//certainty value
    int aStarMapHeight,aStarMapWeight;//map size
    TMap *m_map;
    float SR2;//square root of 2
public:
    astar();
    int aStar_Init( TMap *map , T2DPoint tPoint );//规划到tPoint的路径 返回迭代次数
    T2DPoint aStar_nav_step( T2DPoint *nowPoint );//沿着最小梯度走向一个点

    //private:
    bool map_has_been_filled();//A*算法是否遍历所有点
    long map2Vector(T2DPoint);
    T2DPoint Vector2map(long a);
    bool can_be_updated(int x, int y);
    bool can_be_updated(T2DPoint point);
    bool UpdatePoint(int x, int y,float updateValue);
    bool UpdatePoint(T2DPoint UpdatePoint,float updateValue);
    float getCV(int x, int y);
    void inclassUT();
};
void UnitTest(TMap *map);


#endif // ASTAR_H
