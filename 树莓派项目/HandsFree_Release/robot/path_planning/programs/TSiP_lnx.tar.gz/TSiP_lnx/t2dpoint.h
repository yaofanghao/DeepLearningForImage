﻿#include <cstdlib>
#include <cmath>

#ifndef T2DPOINT_H
#define T2DPOINT_H
#include <QtGlobal>
class T2DPoint
{
public:
    double m_x,m_y;
public:
    T2DPoint();
    T2DPoint(const double x,const double y);
    bool setXY(const double x,const double y);
    double getX();
    double getY();

    bool operator==(T2DPoint point);
};

#endif // T2DPOINT_H
