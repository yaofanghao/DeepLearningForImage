﻿#include "tmap.h"
#include <QList>
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include <QColor>
#include <QImage>
#include <QDebug>
TMap::TMap()
{
}
//从图像的初始化方法
bool TMap::loadFromPicture(const QString &fileName){
    if(m_image.load(fileName)){
        m_height=m_image.height();
        m_width=m_image.width();
        QRgb color;
        for(int y=0;y<m_height;y++){
            for(int x=0;x<m_width;x++){
                color=m_image.pixel(x,y);
                if(qGray(color)>=200){
                    m_mapVector<<TMapPoint(x,y,TMapPoint::FLAT);
                }else{
                    //qDebug()<<"find obstacle at x:"<<x<<"  y:"<<y;
                    m_mapVector<<TMapPoint(x,y,TMapPoint::OBSTACLE);
                }
            }
        }
        return true;
    }else
        return false;
}
//从文本文件建立地图
bool TMap::loadFromText(const QString &fileName){
    QFile f(fileName);
    if(f.open(QFile::ReadOnly)){
        QString strTmp;
        QTextStream log(&f);
        log>>m_width;
        log>>m_height;
#ifdef DEBUG
        qDebug()<<m_width;
        qDebug()<<strTemp;
#endif
        m_image.scaled(m_width,m_height);
        for(int y=0;y<m_height;y++){
            log>>strTmp;
            for(int x=0;y<m_width;x++){
                if(strTmp[x]=='1'){
                    m_image.setPixel(x,y,Qt::black);
                    m_mapVector<<TMapPoint(x,y,TMapPoint::OBSTACLE);
                }else if(strTmp[x]=='1')
                {
                    m_image.setPixel(x,y,Qt::white);
                    m_mapVector<<TMapPoint(x,y,TMapPoint::FLAT);
                }
            }
#ifdef DEBUG
            qDebug()<<strTemp;
#endif
        }
        return true;
    }else
        return false;
}
//保存地图为文本文件
void TMap::toLogFile(const QString &fileName){
    qDebug()<<"in to log file";
    QFile f(fileName);
    if (f.open(QFile::WriteOnly)){
        QTextStream log(&f);
        log << m_image.width()<<endl;
        log << m_image.height()<<endl;
        int count=0;
        for(long i=0;i<m_height*m_width;i++){
            if(m_mapVector[i].isObstacle()){
                log<<'1';
            }
            else{
                log<<'0';
            }
            if(++count==m_width){
                log<<endl;
                count=0;
            }
        }
    }
    f.close();
}
//保存成图片
//TODO
void TMap::toPicture(const QString &fileName)
{
    QImage *img = new QImage (m_width,m_height,QImage::Format_RGB888);
    qDebug()<<m_mapVector.size();
    for(long i=0;i<m_mapVector.size();i++){
        if(m_mapVector[i].isObstacle()){
            img->setPixel(m_mapVector[i].getX(),m_mapVector[i].getY(),0x000000);
        }else{
            img->setPixel(m_mapVector[i].getX(),m_mapVector[i].getY(),0xffffff);
        }
    }
    img->save(fileName);
}
int TMap::getHeight(){
    return m_height;
}
int TMap::getWidth(){
    return m_width;
}
bool TMap::isObstacle(int x, int y)
{
    return m_mapVector[(y * m_width) + x].isObstacle();
}
bool TMap::isFlat(int x, int y){
    return m_mapVector[(y * m_width) + x].isFlat();
}
bool TMap::isObstacle(T2DPoint point){
    return m_mapVector[point.getY() * m_width + point.getX()].isObstacle();
}
bool TMap::isFlat(T2DPoint point){
    return m_mapVector[point.getY() * m_width + point.getX()].isFlat();
}
