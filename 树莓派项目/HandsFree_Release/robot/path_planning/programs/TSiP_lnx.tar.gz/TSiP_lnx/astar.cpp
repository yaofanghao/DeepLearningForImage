﻿#include "astar.h"
#include <QDebug>
#define UNATTACHED 10000
#define ATTACHEDOBSTACAL 9999

astar::astar()
{
    SR2=1.41;
}
int astar::aStar_Init(TMap *map, T2DPoint tPoint){ //update QVector<float> VmapCV
//    qDebug()<<"aStar_Init";
    m_map=map;
    QVector<T2DPoint> lastUpdatedPoints;
    QVector<T2DPoint> updatedPoints;
    //get the map size
    aStarMapWeight=map->getWidth();
    aStarMapHeight=map->getHeight();
    //resize QVector<float> VmapCV;
    VmapCV.resize(aStarMapWeight*aStarMapHeight);
    //fill the VmapCV the default num;
    VmapCV.fill(UNATTACHED);
    //set the target;
    VmapCV[map2Vector(tPoint)]=0;//init the target
    lastUpdatedPoints << tPoint;//
    int loopNum = 0;
    for(;1;){//beging the loop
        loopNum++;
        for(int i=0;i<lastUpdatedPoints.size();i++){//serch the cell next to the last updated cells
            T2DPoint point = lastUpdatedPoints.at(i);
            float cellCV = VmapCV.at(map2Vector(point));
            int x = point.getX();
            int y = point.getY();
            //cross
            if(can_be_updated(x-1,y-1)){
                if(UpdatePoint(x-1,y-1,cellCV+SR2))
                    updatedPoints<<T2DPoint(x-1,y-1);
            }
            if(can_be_updated(x-1,y+1)){
                if(UpdatePoint(x-1,y+1,cellCV+SR2))
                    updatedPoints<<T2DPoint(x-1,y+1);
            }
            if(can_be_updated(x+1,y-1)){
                if(UpdatePoint(x+1,y-1,cellCV+SR2))
                    updatedPoints<<T2DPoint(x+1,y-1);
            }
            if(can_be_updated(x+1,y+1)){
                if(UpdatePoint(x+1,y+1,cellCV+SR2))
                    updatedPoints<<T2DPoint(x+1,y+1);
            }
            //next to
            if(can_be_updated(x-1,y)){
                if(UpdatePoint(x-1,y,cellCV+1))
                    updatedPoints<<T2DPoint(x-1,y);
            }
            if(can_be_updated(x,y-1)){
                if(UpdatePoint(x,y-1,cellCV+1))
                    updatedPoints<<T2DPoint(x,y-1);
            }
            if(can_be_updated(x+1,y)){
                if(UpdatePoint(x+1,y,cellCV+1))
                    updatedPoints<<T2DPoint(x+1,y);
            }
            if(can_be_updated(x,y+1)){
                if(UpdatePoint(x,y+1,cellCV+1))
                    updatedPoints<<T2DPoint(x,y+1);
            }
        }//遍历了本次需要遍历的点
        lastUpdatedPoints=updatedPoints;//更新下一次需要遍历的基本点。
        updatedPoints.clear();//clear the emp
        //qDebug()<<lastUpdatedPoints.size();
        if(lastUpdatedPoints.size()==0) break;
    }
    return loopNum;
}
T2DPoint astar::aStar_nav_step(T2DPoint *nowPoint){//call this function for a step
    int x=nowPoint->getX();
    int y=nowPoint->getY();
    float mincv=10000;
    //x-1
    if(can_be_updated(x-1,y-1)){
        if(mincv>=getCV(x-1,y-1)) mincv=getCV(x-1,y-1);
    }
    if(can_be_updated(x-1,y)){
        if(mincv>=getCV(x-1,y)) mincv=getCV(x-1,y);
    }
    if(can_be_updated(x-1,y+1)){
        if(mincv>=getCV(x-1,y+1)) mincv=getCV(x-1,y+1);
    }
    //x
    if(can_be_updated(x,y-1)){
        if(mincv>=getCV(x,y-1)) mincv=getCV(x,y-1);
    }
    if(can_be_updated(x,y+1)){
        if(mincv>=getCV(x,y+1)) mincv=getCV(x,y+1);
    }
    //x+1
    if(can_be_updated(x+1,y-1)){
        if(mincv>=getCV(x+1,y-1)) mincv=getCV(x+1,y-1);
    }
    if(can_be_updated(x+1,y)){
        if(mincv>=getCV(x+1,y)) mincv=getCV(x+1,y);
    }
    if(can_be_updated(x+1,y+1)){
        if(mincv>=getCV(x+1,y+1)) mincv=getCV(x+1,y+1);
    }
    if(mincv==10000) qDebug()<<"fuck~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~what's wrong";
    if(can_be_updated(x+1,y+1)&&mincv==getCV(x+1,y+1)) return T2DPoint(x+1,y+1);
    if(can_be_updated(x+1,y)&&mincv==getCV(x+1,y)) return T2DPoint(x+1,y);
    if(can_be_updated(x+1,y-1)&&mincv==getCV(x+1,y-1)) return T2DPoint(x+1,y-1);
    if(can_be_updated(x-1,y+1)&&mincv==getCV(x-1,y+1)) return T2DPoint(x-1,y+1);
    if(can_be_updated(x-1,y)&&mincv==getCV(x-1,y)) return T2DPoint(x-1,y);
    if(can_be_updated(x-1,y-1)&&mincv==getCV(x-1,y-1)) return T2DPoint(x-1,y-1);
    if(can_be_updated(x,y+1)&&mincv==getCV(x,y+1)) return T2DPoint(x,y+1);
    if(can_be_updated(x,y-1)&&mincv==getCV(x,y-1)) return T2DPoint(x,y-1);
}

//bool astar::map_has_been_filled(){
//    if(VmapCV.contains(LARGE_NUM)) //如果还有初始化时的大数说明还没有遍历完
//        return FALSE;
//    else
//        return TRUE;
//}

long astar::map2Vector(T2DPoint point){
    return ((point.getX() * aStarMapWeight) + point.getY());
}

T2DPoint astar::Vector2map(long vectorNum){//please initial aStarMapHeight&aStarMapWeight first
    int x=vectorNum%aStarMapWeight;
    int y=(int)vectorNum/aStarMapWeight;
    return T2DPoint(x,y);
}
//judge whether a point can be update
//~is out of the map boundary
//~is an obstacale
bool astar::can_be_updated(int x, int y){
    if( (x<0) || (x>=aStarMapWeight) || (y<0) || (y>=aStarMapHeight) || m_map->isObstacle(x,y))
        return false;
    else
        return true;
}
bool astar::can_be_updated(T2DPoint point){
    int x=point.getX();
    int y=point.getY();
    return can_be_updated(x,y);
}

//update the point
//if the point CV refreshed teturn true
bool astar::UpdatePoint(int x, int y, float updateValue){
    return UpdatePoint(T2DPoint(x,y),updateValue);
}

bool astar::UpdatePoint(T2DPoint UpdatePoint, float updateValue){
    if( VmapCV[map2Vector(UpdatePoint)] == UNATTACHED ){
        VmapCV[map2Vector(UpdatePoint)] = updateValue;
        // qDebug()<<'('<<UpdatePoint.getX()<<','<<UpdatePoint.getY()<<')'<<'='<<updateValue;
        return true;
    }else{//has been attached need to be update??
        float cv=VmapCV[map2Vector(UpdatePoint)];
        if (updateValue<cv){//更近的路径
            VmapCV[map2Vector(UpdatePoint)] = updateValue;
            // qDebug()<<'('<<UpdatePoint.getX()<<','<<UpdatePoint.getY()<<')'<<'='<<updateValue;
            return true;
        }else
            return false;
    }
}

void astar::inclassUT(){
    //类的单元测试

    T2DPoint pstate(199,199);
    for(;1;){
        qDebug()<<'('<<pstate.getX()<<','<<pstate.getY()<<")---------->>>";
        pstate = aStar_nav_step(&pstate);
        if (pstate==T2DPoint(0,30)) break;
    }
}

void UnitTest(TMap *map){
    astar AsSys;
    AsSys.aStar_Init(map,T2DPoint(0,30));
    AsSys.inclassUT();
}

float astar::getCV(int x, int y){
    return VmapCV[(map2Vector(T2DPoint(x,y)))];
}









