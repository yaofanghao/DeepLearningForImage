﻿#include "tscan.h"
#include "tmap.h"
#include <cmath>

#include "tmappoint.h"
#include <qmath.h>
TScan::TScan()
{
}

bool TScan::setSensor(double angle, int num, int scope){
    m_sensorParameter.angle=angle;
    m_sensorParameter.num=num;
    m_sensorParameter.scope=scope;
    return 1;
}
void TScan::setMap(TMap *map){
    m_map = map;
    //    return 1;
}
QVector<TMapPoint> TScan::scanRefresh(void){
    double sx = m_rob->getX();//机器人坐标
    double sy= m_rob->getY();
    double phi=m_rob->getPhi();//机器人角度

    QVector<TMapPoint> obstaclePointVector;

    double angleStart=radians(phi-(m_sensorParameter.angle/2));//扫描始末角度 radians
    double angleStop=radians(phi+(m_sensorParameter.angle/2));
    double anglestep=radians(m_sensorParameter.angle/m_sensorParameter.num);//扫描步进

    int maplimit=qMax(m_map->getHeight(),m_map->getWidth());
    int x,y;
    for (double angleloop=angleStart;angleloop<=angleStop;angleloop+=anglestep){
        for(int i=0;i<=maplimit;i++){
            x=sx+i*(sin(angleloop));
            y=sy-i*(cos(angleloop));//QImage坐标和右手坐标
            if(x<=0
                    ||x>=m_map->getWidth()
                    ||y<=0
                    ||y>=m_map->getHeight()
                    )break;//超出地图范围
            if (((x-sx)*(x-sx)+(y-sy)*(y-sy))>(m_sensorParameter.scope*m_sensorParameter.scope)) {
//                qDebug()<<"break the target ";
                break;
            }
            if (m_map->isObstacle(x,y))
            {
                obstaclePointVector<<TMapPoint(x,y,TMapPoint::OBSTACLE);
                break;
            }
        }
    }
    qDebug()<<obstaclePointVector.size();
    return obstaclePointVector;
}

double TScan::degree(const double radians)
{
    return radians*180/PI;
}

double TScan::radians(const double degree)
{
    return degree*PI/180;
}

void TScan::setRobot(TRobot *rob){
    m_rob=rob;
}
