﻿#include <QApplication>
#include "mainwindow.h"
#include "t2dpoint.h"
#include "tmap.h"
#include "astar.h"

#include <QDebug>
#include <QImage>
#include <QGraphicsPixmapItem>
#include <QGraphicsView>
#include <cmath>

#include "tsipgui.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MainWindow w;
    w.show();
    return a.exec();
}







/**********************************************************************************************/

//int main(int argc, char *argv[])
//{
//    QApplication a(argc, argv);

//    TMap im;
//    im.loadFromPicture("test.png");
//    //  im.loadFromText("MapLog.txt");
//    im.toLogFile("testout.txt");
//    im.toPicture("testout.png");

//    QImage image("test.png");

//    MainWindow w;
//    w.show();

//    astar *navsys = new astar;
//    navsys->aStar_Init(&im,T2DPoint(90,190));
//    T2DPoint pstate(199,0);
//    for(;1;){
//        //  qDebug()<<'('<<pstate.getX()<<','<<pstate.getY()<<")---------->>>";
//        pstate = navsys->aStar_nav_step(&pstate);
//        w.img->setPixel(QPoint(pstate.getX(),pstate.getY()),0x00ff0000);
//        if (pstate==T2DPoint(90,190)) break;
//    }
//    return a.exec();
//}
