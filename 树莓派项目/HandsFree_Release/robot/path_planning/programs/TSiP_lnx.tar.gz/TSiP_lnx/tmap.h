﻿#include <QImage>
#include <QVector>
#include "tmappoint.h"
#include <QMatrix>

#ifndef TMAP_H
#define TMAP_H

class TMap
{
    QImage m_image;
    QVector<TMapPoint> m_mapVector;//地图基本点容器
    int m_height,m_width;//地图大小
    int m_radio;//像素对应比例
public:
    TMap();
    bool loadFromPicture(const QString &fileName);
    bool loadFromText(const QString &fileName);
    void toLogFile(const QString &fileName);
    void toPicture(const QString &fileName);
    int getHeight();
    int getWidth();
    bool isObstacle(int x,int y);
    bool isFlat(int x,int y);
    bool isObstacle(T2DPoint point);
    bool isFlat(T2DPoint point);
};

#endif // TMAP_H
