﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QImage>
#include <QGraphicsScene>
#include <QPixmap>
#include <QTimer>
#include <QtGlobal>

#include "tscan.h"
#include "trobot.h"
#include "tmap.h"
#include "tsipgui.h"
#include "astar.h"
#include "tscan.h"
#include "vffalgorithm.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    TSiPGUI *gui ;//显示
    TScan *scan;//传感器
    TRobot *rob;//机器人
    TMap *map;//地图
    astar *astarSys;//a*算法系统
    VFFAlgorithm *VFFSys;//vff计算系统
    T2DPoint target;
    QTimer *timer;
public:
    //    QImage *img;//显示的图像
    void UnitTest(void);
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void randomastarVFFAlgorithm(void);
    void simpleaAstarVFFAlgorithm(void);
    void paintEvent(QPaintEvent *);
    void aStarAlgorithm(void);
    void aStarVFFAlgorithm(void);
private:
#define PI 3.1415926
    double degree(const double radians);
    double radians(const double degree);

private slots:
    void timeUpdate(void);

    void aStarPeriod(void);

    void aStarVFFPeriod(void);

    void simpleaAstarVFFPeriod(void);

    void randomastarVFFPeriod(void);



    void on_action_triggered();//打开地图文件

    void on_pushButton_2_clicked();//设置目的地坐标

    void on_pushButton_3_clicked();//设置当前文字

    void on_checkBox_clicked();//A*

    void on_checkBox_2_clicked();//改进A*

    void on_checkBox_3_clicked();//A* VFF

    void on_pushButton_clicked(bool checked);//start simu

    void on_pushButton_4_clicked();

    void on_checkBox_4_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
