﻿#include"tmap.h"
#include"trobot.h"
#include <QDebug>
#include <QVector>
#include "tmappoint.h"
#ifndef TSCAN_H
#define TSCAN_H

class TScan
{

    struct SENSORPARAMETER{
        int angle;//扫描角度 indegree
        int num;//扫描点数
        int scope;//扫描范围 直径
    }m_sensorParameter;
    TRobot *m_rob;
    TMap *m_map;
public:
    TScan();
    bool setSensor(double angle,int num,int scope);//设置传感器参数
    bool setSensor(const TScan::SENSORPARAMETER &sence);
    void setMap(TMap *map);//装载一张gripmap
    void setRobot(TRobot *rob);
    TMap* getmap(){
        return m_map;
    }
    TRobot* getRobot(){
        return m_rob;
    }

    QVector<TMapPoint> scanRefresh();//扫描

private:
#define PI 3.1415926
    double degree(const double radians);
    double radians(const double degree);
};

#endif // TSCAN_H
