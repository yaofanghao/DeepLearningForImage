﻿#include "tsipgui.h"


/*模块说明******************************************************/
/*
 *
 */
/*************************************************************/


class DistancePicker: public QwtPlotPicker//plotpicker
{
public:
    DistancePicker( QWidget *canvas ):
        QwtPlotPicker( canvas )
    {
        setTrackerMode( QwtPicker::ActiveOnly );
        setStateMachine( new QwtPickerDragLineMachine() );
        setRubberBand( QwtPlotPicker::PolygonRubberBand );
    }

    virtual QwtText trackerTextF( const QPointF &pos ) const
    {
        QwtText text;

        const QPolygon points = selection();
        if ( !points.isEmpty() )
        {
            QString num;
            num.setNum( QLineF( pos, invTransform( points[0] ) ).length() );

            QColor bg( Qt::white );
            bg.setAlpha( 200 );

            text.setBackgroundBrush( QBrush( bg ) );
            text.setText( num );
        }
        return text;
    }
};

TSiPGUI::TSiPGUI()
{
    plot = new QwtPlot();
    d_curve = new QwtPlotCurve( "d_curve" );
    curve_map = new QwtPlotCurve( "curve_map" );
    curve_nav = new QwtPlotCurve( "curve_nav" );
    curve_nav2 = new QwtPlotCurve( "curve_nav2" );
    curve_scan = new QwtPlotCurve( "curve_scan" );
    curve_rob = new QwtPlotCurve( "curve_rob" );
    curve_boundary = new QwtPlotCurve("curve_boundary");
    initPlot();
}

TSiPGUI::TSiPGUI(QwtPlot *uiplot){
    plot = uiplot;
    d_curve = new QwtPlotCurve( "d_curve" );
    curve_map = new QwtPlotCurve( "curve_map" );
    curve_nav = new QwtPlotCurve( "curve_nav" );
    curve_nav2 = new QwtPlotCurve( "curve_nav2" );
    curve_scan = new QwtPlotCurve( "curve_scan" );
    curve_rob = new QwtPlotCurve( "curve_rob" );
    curve_boundary = new QwtPlotCurve("curve_boundary");
    initPlot();
}

void TSiPGUI::initPlot(){
    plot->autoRefresh();
    plot->setTitle( "TSiP GUI" );
    //    plot->setAxisScale(QwtPlot::xBottom, 0.0, 200.0);
    //    plot->setAxisScale(QwtPlot::yRight, 0.0, 200.0);

    plot->axisScaleEngine(QwtPlot::yLeft)->setAttribute(QwtScaleEngine::Inverted);
    //绘制网格
    QwtPlotGrid *grid = new QwtPlotGrid();
    grid->attach( plot );

    //移动 panning with the left mouse button
    (void )new QwtPlotPanner( plot->canvas() );

    //    //缩放 zoom in/out with the wheel
    QwtPlotMagnifier *magnifier = new QwtPlotMagnifier(plot->canvas());
    magnifier->setMouseButton( Qt::NoButton );
    magnifier->setZoomInKey(Qt::Key_Equal,Qt::ControlModifier);
    magnifier->setZoomOutKey(Qt::Key_Minus,Qt::ControlModifier);

    //测量两点距离 distanve measurement with the right mouse button
    DistancePicker *picker = new DistancePicker( plot->canvas() );
    picker->setMousePattern( QwtPlotPicker::MouseSelect1, Qt::RightButton );
    picker->setRubberBandPen( QPen( Qt::blue ) );

    //d_curve
    d_curve->setRenderThreadCount( 1 ); // 0: use QThread::idealThreadCount()
    d_curve->setSymbol( new QwtSymbol( QwtSymbol::Rect  , Qt::black,
                                       QPen( Qt::black ), QSize( 10, 10 ) ) );
    d_curve->setStyle(QwtPlotCurve::Dots);

    //curve_map地图样式
    curve_map->setRenderThreadCount( 1 ); // 0: use QThread::idealThreadCount()
    curve_map->setSymbol( new QwtSymbol( QwtSymbol::XCross  , Qt::black,
                                         QPen( Qt::black ), QSize( 3, 3 ) ) );
    curve_map->setStyle(QwtPlotCurve::Dots);
    //curve_boundary地图边界样式
    curve_boundary->setRenderThreadCount( 1 ); // 0: use QThread::idealThreadCount()
    curve_boundary->setSymbol( new QwtSymbol( QwtSymbol::XCross  , Qt::blue,
                                              QPen( Qt::blue), QSize( 5, 5 ) ) );
    curve_boundary->setStyle(QwtPlotCurve::Lines );
    //curve_nav导航点样式
    curve_nav->setRenderThreadCount( 1 ); // 0: use QThread::idealThreadCount()
    curve_nav->setSymbol( new QwtSymbol( QwtSymbol::Triangle   , Qt::green,
                                         QPen( Qt::green ), QSize( 5, 5 ) ) );
    curve_nav->setStyle(QwtPlotCurve::Dots);

    curve_nav2->setRenderThreadCount( 1 ); // 0: use QThread::idealThreadCount()
    curve_nav2->setSymbol( new QwtSymbol( QwtSymbol::Triangle   , Qt::blue,
                                         QPen( Qt::blue ), QSize( 5, 5 ) ) );
    curve_nav2->setStyle(QwtPlotCurve::Dots);

    //curve_rob机器人样式
    curve_rob->setRenderThreadCount( 1 ); // 0: use QThread::idealThreadCount()
    curve_rob->setSymbol( new QwtSymbol( QwtSymbol::Rect  , Qt::black,
                                         QPen( Qt::black ), QSize( 5, 5 ) ) );
    curve_rob->setStyle(QwtPlotCurve::Dots);

    //curve_scan
    curve_scan->setRenderThreadCount( 1 ); // 0: use QThread::idealThreadCount()
    curve_scan->setSymbol( new QwtSymbol( QwtSymbol::Diamond   , Qt::red,
                                          QPen( Qt::black ), QSize( 5, 5 ) ) );
    curve_scan->setStyle(QwtPlotCurve::Dots);
    //attach to plot
    d_curve->attach( plot );
    curve_map->attach(plot);
    curve_nav->attach(plot);
    curve_nav2->attach(plot);
    curve_rob->attach(plot);
    curve_scan->attach(plot);
    curve_boundary->attach(plot);

    //    plot->resize(600,600);
    plot->show();
}

//*curve 需要修改的曲线 sample 点集合
void TSiPGUI::drawCurve(QwtPlotCurve *curve, const QPolygonF &samples){
    curve->setSamples(samples);
}
void TSiPGUI::drawCurve(QwtPlotCurve *curve, QPolygonF *samples){
    curve->setSamples(*samples);
}

void TSiPGUI::UnitTest(){//gui 单元测试
    QPolygonF *aaa = new QPolygonF();
    aaa->append(QPointF(100,100));
    drawCurve(d_curve,aaa);
    delete  aaa;

    QPolygonF *bbb = new QPolygonF();
    bbb->append(QPointF(90,115));
    drawCurve(d_curve,bbb);
    delete  bbb;

    TMap *map = new TMap();
    map->loadFromPicture("test.png");
    drawMap( map );
}

void TSiPGUI::drawMap(TMap *map){
    int w = map->getWidth();
    int h = map->getHeight();
    QPolygonF *mapPoint = new QPolygonF();
    for (int y = 0; y < h ; y++){
        for(int x = 0; x < w; x++){
            if (map->isObstacle(x,y)){
                mapPoint->append(QPointF(x,y));
            }
        }
    }
    drawCurve(curve_map,mapPoint);
    delete mapPoint;
    QPolygonF *mapboundary = new QPolygonF();
    for( int x = 0 ;x <= w ; x++){
        mapboundary->append(QPointF(x,0));
    }
    for(int y = 0; y <= h; y++){
        mapboundary->append(QPointF(w , y));
    }
    for( int x = w ;x >= 0 ; x--){
        mapboundary->append(QPointF( x , h));
    }
    for(int y=h; y>=0 ;y-- ){
        mapboundary->append(QPointF(0 ,y));
    }
    drawCurve(curve_boundary,mapboundary);
    delete mapboundary;
}
void TSiPGUI::drawScan(const QVector<TMapPoint> *scanPoint){
    int num = scanPoint->size();
    QPolygonF *scanCurvePoint = new QPolygonF;
    TMapPoint p;
    for (int i =0;i <num;i++){
        p=scanPoint->at(i);
        double x = p.getX();
        double y = p.getY();
        scanCurvePoint->append(QPointF(x,y));
    }
    drawCurve(curve_scan,scanCurvePoint);
    delete scanCurvePoint;
}

void TSiPGUI::draw_nav(const QVector<T2DPoint> *navPoint){
    int num = navPoint->size();
    QPolygonF *navCurvePoint = new QPolygonF;
    T2DPoint p;
    for (int i =0;i <num;i++){
        p=navPoint->at(i);
        double x = p.getX();
        double y = p.getY();
        navCurvePoint->append(QPointF(x,y));
    }
    //    qDebug()<<navCurvePoint->size();
    drawCurve(curve_nav,navCurvePoint);
    delete navCurvePoint;
    plot->update();
}

void TSiPGUI::drawRob(TRobot *rob){
    //    curve_rob->detach();
    //    delete curve_rob;
    //    curve_rob = new QwtPlotCurve( "curve_rob" );
    //    curve_rob->setRenderThreadCount( 0 ); // 0: use QThread::idealThreadCount()
    //    setRobStyele(rob);
    ////    curve_rob->setSymbol( new QwtSymbol( QwtSymbol::Rect  , Qt::black,
    ////                                         QPen( Qt::black ), QSize( 5, 5 ) ) );
    //    curve_rob->setStyle(QwtPlotCurve::Dots);
    //    curve_rob->attach(plot);
    QPolygonF *robPos = new QPolygonF;
    setRobStyele(rob);
    robPos->append(QPointF(rob->getX(),rob->getY()));

    drawCurve(curve_rob,robPos);
    delete robPos;
}
void TSiPGUI::setRobStyele(TRobot *rob){
    QwtSymbol *symbol = new QwtSymbol();

    QPen pen( Qt::black, 2 );
    pen.setJoinStyle( Qt::MiterJoin );

    symbol->setPen( pen );
    symbol->setBrush( Qt::red );

    QPainterPath path;
    path.moveTo( 0, 0 );
    path.lineTo( 0, -1 );
    path.lineTo( -2, -1 );
    path.lineTo( 0, -6 );
    path.lineTo( 2, -1 );
    path.lineTo( 0, -1 );

    QTransform transform;
    transform.rotate( rob->getPhi()+90 );
    path = transform.map( path );

    symbol->setPath( path );
    symbol->setPinPoint( QPointF( 0.0, 0.0 ) );
    symbol->setSize( 10, 14 );

    curve_rob->setSymbol(symbol);

    //delete symbol;
}
