#ifndef VFFALGORITHM_H
#define VFFALGORITHM_H

#include "tscan.h"
#include "trobot.h"
#include <QVector2D>
class VFFAlgorithm
{
    TScan *scan;
    QVector2D VFFresult;
    double Fconst;//const F to cal each f
public:
    VFFAlgorithm();
    void setTScan(TScan *scanToLoad);
    QVector2D VFFstep();
    void VFFUnitTest();

};

#endif // VFFALGORITHM_H
