http://www.mrpt.org/
http://reference.mrpt.org/
http://www.mrpt.org/forum-users/
http://www.mrpt.org/Videos

== build tips ==

sudo apt-get install libsuitesparse-dev
sudo apt-get install libwxgtk2.8-0 libwxgtk2.8-dev python-wxgtk2.8 
sudo apt-get install libblas-dev libatlas-dev

export OpenCV_DIR=/opt/opencv-2.4.5
export LIBRARY_PATH=$LIBRARY_PATH:/opt/opencv-2.4.5/lib
