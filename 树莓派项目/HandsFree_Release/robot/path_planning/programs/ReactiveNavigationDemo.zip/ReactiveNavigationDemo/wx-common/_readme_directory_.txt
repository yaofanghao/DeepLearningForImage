The "wx-common" directory contains wxWidgets-related classes which are reused accross two or more GUI applications.

    ~~  The MRPT Library  ~~
    Jose Luis Blanco, 2008 Jun



