/*
 * Manager.h
 *
 *  Created on: Jan 25, 2015
 *      Author: roiyeho
 */

#ifndef MANAGER_H_
#define MANAGER_H_

#include "Plan.h"
#include "Behavior.h"

class Manager {
public:
	Manager(Plan *plan);
	void run();
	virtual ~Manager();
private:
	Plan *plan;
	Behavior *currBehavior;
};

#endif /* MANAGER_H_ */
