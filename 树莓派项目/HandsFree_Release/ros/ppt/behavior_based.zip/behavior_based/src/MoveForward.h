/*
 * MoveForward.h
 *
 *  Created on: Jan 25, 2015
 *      Author: roiyeho
 */

#ifndef MOVEFORWARD_H_
#define MOVEFORWARD_H_

#include "Behavior.h"
#include <ros/ros.h>
#include "sensor_msgs/LaserScan.h"
#include <cmath>

class MoveForward: public Behavior {
public:
	MoveForward();
	virtual bool startCond();
	virtual void action();
	virtual bool stopCond();
	virtual ~MoveForward();
private:
	const static double FORWARD_SPEED_MPS = 0.5;
	const static double MIN_SCAN_ANGLE_RAD = -30.0/180 * M_PI;
	const static double MAX_SCAN_ANGLE_RAD = +30.0/180 * M_PI;
	const static float MIN_PROXIMITY_RANGE_M = 0.5;

    ros::NodeHandle node;
    ros::Publisher commandPub;
    ros::Subscriber laserSub;

    void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan);
    bool keepMovingForward;
};

#endif /* MOVEFORWARD_H_ */
