/*
 * ObstacleAvoidPlan.h
 *
 *  Created on: Jan 25, 2015
 *      Author: roiyeho
 */

#ifndef OBSTACLEAVOIDPLAN_H_
#define OBSTACLEAVOIDPLAN_H_

#include "Plan.h"

class ObstacleAvoidPlan: public Plan {
public:
	ObstacleAvoidPlan();
	virtual ~ObstacleAvoidPlan();
};

#endif /* OBSTACLEAVOIDPLAN_H_ */
