/*
 * Plan.cpp
 *
 *  Created on: Jan 25, 2015
 *      Author: roiyeho
 */

#include "Plan.h"
#include <iostream>

Plan::Plan() : startBehavior(NULL) {

}

Behavior *Plan::getStartBehavior() {
    return startBehavior;
}

Plan::~Plan() {

}

