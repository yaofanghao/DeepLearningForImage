/*
 * TurnLeft.h
 *
 *  Created on: Jan 25, 2015
 *      Author: roiyeho
 */

#ifndef TURNLEFT_H_
#define TURNLEFT_H_

#include "Behavior.h"
#include <ros/ros.h>
#include "sensor_msgs/LaserScan.h"
#include <cmath>

class TurnLeft: public Behavior {
public:
	TurnLeft();
	virtual bool startCond();
	virtual void action();
	virtual bool stopCond();
	virtual ~TurnLeft();
private:
	const static double TURN_SPEED_MPS = 1.0;
	const static double MIN_SCAN_ANGLE_RAD = -30.0/180 * M_PI;
	const static double MAX_SCAN_ANGLE_RAD = 0;
	const static float MIN_PROXIMITY_RANGE_M = 0.5;

	ros::NodeHandle node;
	ros::Publisher commandPub;
	ros::Subscriber laserSub;

	void scanCallback(const sensor_msgs::LaserScan::ConstPtr& scan);
	bool keepTurningLeft;
};

#endif /* TURNLEFT_H_ */
