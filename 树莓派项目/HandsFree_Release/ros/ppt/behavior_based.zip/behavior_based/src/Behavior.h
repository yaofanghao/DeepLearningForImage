/*
 * Behavior.h
 *
 *  Created on: Jan 25, 2015
 *      Author: roiyeho
 */

#ifndef BEHAVIOR_H_
#define BEHAVIOR_H_

#include <vector>
using namespace std;

class Behavior {
private:
    vector<Behavior *> _nextBehaviors;

public:
    Behavior();
    virtual bool startCond() = 0;
	virtual bool stopCond() = 0;
	virtual void action() = 0;

	Behavior *addNext(Behavior *beh);
	Behavior *selectNext();
	virtual ~Behavior();
};

#endif /* BEHAVIOR_H_ */


