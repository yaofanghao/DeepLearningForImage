/*
 * Plan.h
 *
 *  Created on: Jan 25, 2015
 *      Author: roiyeho
 */

#ifndef PLAN_H_
#define PLAN_H_

#include <vector>
#include "Behavior.h"
using namespace std;

class Plan {
public:
	Plan();
	Behavior *getStartBehavior();
	virtual ~Plan();
protected:
    vector<Behavior *> behaviors;
    Behavior *startBehavior;
};

#endif /* PLAN_H_ */
