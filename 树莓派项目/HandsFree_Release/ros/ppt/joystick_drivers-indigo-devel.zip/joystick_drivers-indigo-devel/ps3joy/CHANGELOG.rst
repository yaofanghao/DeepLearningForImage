^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ps3joy
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.10.1 (2015-05-24)
-------------------
* Remove stray architechture_independent flags
* Contributors: Jonathan Bohren, Scott K Logan

1.10.0 (2014-06-26)
-------------------
* First indigo reelase
* Update ps3joy/package.xml URLs with github user ros to ros-drivers
* Prompt for sudo password when required
* Contributors: Felix Kolbe, Jonathan Bohren, dawonn
